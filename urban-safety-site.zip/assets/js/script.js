// Footer year
document.addEventListener('DOMContentLoaded', function(){
  var y = document.getElementById('year');
  if (y) y.textContent = new Date().getFullYear();

  // Countdown
  var el = document.getElementById('countdown');
  if (!el) return;
  var targetStr = el.getAttribute('data-target');
  if (!targetStr) return;
  var target = new Date(targetStr);

  function pad(n){ return String(n).padStart(2,'0'); }
  function tick(){
    var now = new Date();
    var diff = Math.max(0, target - now);
    var sec = Math.floor(diff / 1000);
    var days = Math.floor(sec / 86400);
    var hours = Math.floor((sec % 86400) / 3600);
    var mins = Math.floor((sec % 3600) / 60);
    var secs = sec % 60;
    var byId = function(id, v){ var n = document.getElementById(id); if(n) n.textContent = v; };
    byId('cd-days', days);
    byId('cd-hours', pad(hours));
    byId('cd-mins', pad(mins));
    byId('cd-secs', pad(secs));
  }
  tick();
  setInterval(tick, 1000);
});
